AJAX File Upload
==========

AJAX File Upload is a jQuery plugin to enable cross-browser AJAX-like file uploads.

Requirements
--------------------

jQuery 1.6.1+

Browser Support
--------------------

The following browsers are supported:

- Google Chrome 5.0+
- Internet Explorer 6+
- Mozilla Firefox 3.6+
- Opera 10.5+
- Safari 5+

All recent versions of these browsers should be supported. If not I'd like to hear about it. Versions prior to those
listed here may work but are untested.

Contributors
--------------------

Steven Barnett

License
--------------------

Released under the [MIT license](http://www.opensource.org/licenses/MIT)
